import util.*

class Hello{
	def event;
	
	def sayHello(name){
		return "Hello ${name}! How are you today? Because I am very Groovy today"		
	}
	
}
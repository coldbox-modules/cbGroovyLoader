package util

class Phone{
	def phone = "";
	def areacode = "";
}
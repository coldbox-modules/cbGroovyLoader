//incoming varCollection
def myArray = [1,2,3,4]
//add to varCollection
varCollection['MyArray'] =  myArray
